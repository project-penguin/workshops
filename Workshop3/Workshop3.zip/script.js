let products = [
    {
        title: "Cake",
        description: "Tasty cake",
        image: "cake.png",
        imageAlt: "A blue monster cake",
        price: 10
    },
    {
        title: "Milk",
        description: "Who doesn't like milk",
        image: "milk.jpg",
        imageAlt: "A woman drinking a tall glass of milk",
        price: 1
    },
    {
        title: "Hat",
        description: "You want a hat? Here it is.",
        image: "hat.jpeg",
        imageAlt: "A established fellow wearing a fez",
        price: 205
    },
    {
        title: "Crisp High Five",
        description: "All the encouragement you could want",
        image: "hi5.jpg",
        imageAlt: "Dog gives man a solid hi five",
        price: 3847
    },
    {
        title: "Milk",
        description: "Who doesn't like milk",
        image: "milk.jpg",
        imageAlt: "A woman drinking a tall glass of milk",
        price: 1
    }
];

let topProductsElement = document.getElementById("topproductlist");

function addProductCard(parentElement, products) {
    for (let i = 0; i < products.length; i++) {
        console.log(products[i].title);
        const card = document.createElement("div");
        card.setAttribute("class", "itemcard");

        const image = document.createElement("img");
        image.setAttribute("src", "images/" + products[i].image);
        image.setAttribute("alt", products[i].imageAlt);
        card.append(image);

        const title = document.createElement("h2");
        title.innerText = products[i].title;
        card.append(title);

        const price = document.createElement("p");
        price.innerText = "$" + products[i].price;
        card.append(price);

        parentElement.append(card);
    }
}

addProductCard(topProductsElement, products);
