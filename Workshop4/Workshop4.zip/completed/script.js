let products = [
  {
    title: "Cake",
    description: "Tasty cake",
    image: "cake.png",
    imageAlt: "A blue monster cake",
    price: 10,
  },
  {
    title: "Milk",
    description: "Who doesn't like milk",
    image: "milk.jpg",
    imageAlt: "A woman drinking a tall glass of milk",
    price: 1,
  },
  {
    title: "Hat",
    description: "You want a hat? Here it is.",
    image: "hat.jpeg",
    imageAlt: "A established fellow wearing a fez",
    price: 205,
  },
  {
    title: "Crisp High Five",
    description: "All the encouragement you could want",
    image: "hi5.jpg",
    imageAlt: "Dog gives man a solid hi five",
    price: 3847,
  },
  {
    title: "Milk",
    description: "Who doesn't like milk",
    image: "milk.jpg",
    imageAlt: "A woman drinking a tall glass of milk",
    price: 1,
  },
];

topProductsElement = document.getElementById("topproductlist");

function addProductCard(parentElement, products) {
  for (let i = 0; i < products.length; i++) {
    console.log(products[i].title);
    const card = document.createElement("div");
    card.setAttribute("class", "itemcard");

    const image = document.createElement("img");
    image.setAttribute("src", "images/" + products[i].image);
    image.setAttribute("alt", products[i].imageAlt);
    card.append(image);

    const title = document.createElement("h2");
    title.innerText = products[i].title;
    card.append(title);

    const price = document.createElement("p");
    price.innerText = "$" + products[i].price;
    card.append(price);

    card.onclick = function () {
      populateDialog(products[i]);
      openDialog();
    };

    parentElement.append(card);
  }
}

addProductCard(topProductsElement, products);

function openDialog() {
  const dialog = document.getElementById("dialogbackground");
  dialog.classList.remove("hidden");
}

function closeDialog() {
  const dialog = document.getElementById("dialogbackground");
  dialog.classList.add("hidden");
}

document.getElementById("closebutton").onclick = closeDialog;

function buyThing(product) {
  return function () {
    alert("You bought " + product.title + "!");
  };
}

function populateDialog(product) {
  const title = document.getElementById("dialogtitle");
  const description = document.getElementById("dialogdescription");
  const image = document.getElementById("dialogimage");
  const price = document.getElementById("dialogprice");
  const buyButton = document.getElementById("buybutton");

  title.innerText = product.title;
  description.innerText = product.description;
  price.innerText = "$" + product.price;
  image.src = "images/" + product.image;
  image.alt = product.imageAlt;

  buyButton.onclick = buyThing(product);
}
